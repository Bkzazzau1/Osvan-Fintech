// lib/config/env.dart
import 'package:flutter/foundation.dart' show kIsWeb, defaultTargetPlatform;
import 'package:flutter/material.dart' show TargetPlatform;

/// Backend URL config.
/// 
/// Default points to production (https://fintech.osvan.africa).
/// Override at runtime with --dart-define if needed, e.g.:
///   flutter run --dart-define=OSVAN_API_BASE=http://127.0.0.1:8000
///   flutter run -d emulator-5554 --dart-define=OSVAN_API_BASE=http://10.0.2.2:8000
class Env {
  /// Compile-time constant so it is safe in `const` constructors:
  /// Example: `const CryptoView(baseUrl: Env.apiBaseUrl)`
  static const String apiBaseUrl = String.fromEnvironment(
    'OSVAN_API_BASE',
    defaultValue: 'https://fintech.osvan.africa', // ✅ production default
  );

  /// Runtime helper (use only if you didn’t pass a --dart-define).
  /// Normally returns the same as [apiBaseUrl], but can adapt for emulator.
  static String get autoBaseUrl {
    // If a custom value was provided via --dart-define, use it directly.
    if (apiBaseUrl != 'https://fintech.osvan.africa') return apiBaseUrl;

    // Otherwise, fallback per platform (only relevant for dev).
    if (kIsWeb) return apiBaseUrl; // keep prod for web
    if (defaultTargetPlatform == TargetPlatform.android) {
      return 'http://10.0.2.2:8000'; // Android emulator local dev
    }
    return apiBaseUrl; // prod default
  }
}
