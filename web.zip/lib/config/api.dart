// lib/config/api.dart
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

// ---- Static constant (back-compat) ----
const String kApiBaseUrl = 'https://fintech.osvan.africa/api';

// ---- Prefer dotenv if present; else fallback to constant ----
String resolveBaseUrl() {
  final fromEnv = dotenv.env['API_BASE_URL'];
  if (fromEnv != null && fromEnv.trim().isNotEmpty) {
    return fromEnv.trim().replaceFirst(RegExp(r'/$'), '');
  }
  return kApiBaseUrl.replaceFirst(RegExp(r'/$'), '');
}

// ---- Riverpod provider ----
final baseUrlProvider = Provider<String>((_) => resolveBaseUrl());

// ---- Helpers: safe URL joining & Uri builder ----
String apiJoin(String base, String path) {
  final b = base.endsWith('/') ? base.substring(0, base.length - 1) : base;
  final p = path.startsWith('/') ? path.substring(1) : path;
  return '$b/$p';
}

Uri apiUri(String baseOrPath,
    [String? maybePath, Map<String, dynamic>? query]) {
  if (maybePath == null) return Uri.parse(baseOrPath);
  final url = apiJoin(baseOrPath, maybePath);
  return Uri.parse(url).replace(
    queryParameters: query?.map((k, v) => MapEntry(k, '$v')),
  );
}
