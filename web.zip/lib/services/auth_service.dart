// lib/services/auth_service.dart
import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:get_storage/get_storage.dart';
import 'package:osvan_app/config/env.dart';

class AuthService {
  // ---- storage (web & mobile via GetStorage) ----
  static final GetStorage _box = GetStorage();

  /// Init storage early in app bootstrap (e.g., in main()).
  static Future<void> init() async {
    // Always init safely; the flag is optional for your own checks.
    await GetStorage.init();
    await _box.writeIfNull('__init__', true);
  }

  // ---- token helpers ----
  /// Access/JWT token
  static Future<String?> getToken() async {
    // prefer "access", fall back to "token"
    return _box.read<String>('access') ?? _box.read<String>('token');
  }

  /// Refresh token
  static Future<String?> getRefresh() async {
    return _box.read<String>('refresh');
  }

  /// Persist tokens
  static Future<void> setTokens({String? access, String? refresh}) async {
    if (access != null) {
      await _box.write('access', access);
      await _box.write('token', access); // backward compat
    }
    if (refresh != null) {
      await _box.write('refresh', refresh);
    }
  }

  /// Clear tokens locally
  static Future<void> clear() async {
    await _box.remove('access');
    await _box.remove('token');
    await _box.remove('refresh');
    // If you cache profile/flags, clear them here as well
    // await _box.remove('user_profile');
    // await _box.remove('has_pin');
  }

  /// Quick boolean for guards
  static Future<bool> isLoggedIn() async =>
      (await getToken())?.isNotEmpty == true;

  // ---- Username/password login against /api/token/ (with fallbacks) ----
  ///
  /// Primary (Django SimpleJWT):
  ///   POST /api/token/  -> { "access": "...", "refresh": "..." }
  ///
  /// Fallbacks cover common variants. Stores tokens on success.
  static Future<Map<String, dynamic>> login({
    required String username,
    required String password,
    required String email,
  }) async {
    final base = _normalizeBaseUrl(Env.autoBaseUrl);
    final dio = Dio(BaseOptions(
      baseUrl: base,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 20),
      headers: {
        'Authorization': null, // ensure no stale token sent
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ));

    final candidates = <String>[
      // Primary (Django SimpleJWT)
      '/api/token/',
      // Other patterns we’ve seen
      '/api/auth/jwt/create/',
      '/api/auth/login/',
      '/api/v1/auth/login/',
    ];

    dynamic lastError;
    for (final path in candidates) {
      try {
        final r = await dio.post<Map<String, dynamic>>(
          path,
          data: {
            'username': username,
            'password': password,
          },
        );

        final data = r.data ?? {};
        final map = data['data'] is Map ? (data['data'] as Map) : data;

        final access = (map['access'] ?? map['token'])?.toString().trim();
        final refresh = map['refresh']?.toString().trim();

        if ((access?.isNotEmpty ?? false)) {
          await setTokens(access: access, refresh: refresh);
          return Map<String, dynamic>.from(data);
        }

        // Response didn’t include tokens → treat as error to try next endpoint
        lastError = DioException.badResponse(
          statusCode: r.statusCode ?? 400,
          requestOptions: r.requestOptions,
          response: r,
        );
      } on DioException catch (e) {
        lastError = e; // try next
      } catch (e) {
        lastError = e;
      }
    }

    // Exhausted candidates
    if (lastError is DioException) throw lastError;
    throw DioException(
      requestOptions: RequestOptions(path: '$base/api/token/'),
      message: 'Login failed: unknown error',
    );
  }

  /// Logout:
  /// 1) (optional) Notify server to invalidate refresh token.
  /// 2) Clear local tokens.
  static Future<void> logout({bool notifyServer = true}) async {
    final access = await getToken();
    final refresh = await getRefresh();

    if (notifyServer && (access != null || refresh != null)) {
      final base = _normalizeBaseUrl(Env.autoBaseUrl);
      final dio = Dio(BaseOptions(
        baseUrl: base,
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
        headers: {
          if (access != null) 'Authorization': 'Bearer $access',
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
      ));

      // Try a few common server-logout/blacklist endpoints.
      final candidates = <String>[
        '/api/v1/auth/logout/', // your preferred endpoint
        '/api/auth/logout/', // generic
        '/api/token/blacklist/', // SimpleJWT blacklist (expects {"refresh": ...})
      ];

      for (final path in candidates) {
        try {
          await dio.post<Map<String, dynamic>>(
            path,
            data: jsonEncode({'refresh': refresh}),
            options: Options(headers: {
              if (access != null) 'Authorization': 'Bearer $access',
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            }),
          );
          break; // if one succeeds, we’re done
        } catch (_) {
          // swallow; try next candidate
        }
      }
    }

    // Always clear locally
    await clear();
  }

  // ---- utils ----
  static String _normalizeBaseUrl(String base) {
    if (base.isEmpty) return '';
    return base.endsWith('/') ? base.substring(0, base.length - 1) : base;
  }
}

// ---- Attach JWT to Dio & auto-refresh on 401 -------------------------------
// (Optional: skip if your ApiClient already handles it.)
extension AuthDio on AuthService {
  static void attachJwtRefresh(Dio dio) {
    dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (opts, handler) async {
          final access = await AuthService.getToken();
          if (access != null && access.isNotEmpty) {
            opts.headers['Authorization'] = 'Bearer $access';
          }
          handler.next(opts);
        },
        onError: (e, handler) async {
          final resp = e.response;
          final is401 = resp?.statusCode == 401;
          final hadAuth = e.requestOptions.headers['Authorization'] != null;

          if (is401 && hadAuth) {
            final newAccess = await _tryRefresh(dio);
            if (newAccess != null) {
              final retried =
                  await _retryWithNewToken(dio, e.requestOptions, newAccess);
              return handler.resolve(retried);
            }
          }
          handler.next(e);
        },
      ),
    );
  }

  /// Try a list of common refresh endpoints until one succeeds.
  static Future<String?> _tryRefresh(Dio dio) async {
    final refresh = await AuthService.getRefresh();
    if (refresh == null || refresh.isEmpty) return null;

    final base = AuthService._normalizeBaseUrl(
      dio.options.baseUrl.isNotEmpty ? dio.options.baseUrl : Env.autoBaseUrl,
    );

    final candidates = <String>[
      '$base/api/token/refresh/',
      '$base/api/auth/jwt/refresh/',
      '$base/api/v1/auth/refresh/',
      '$base/api/auth/refresh/',
    ];

    for (final url in candidates) {
      try {
        final r = await dio.post<Map<String, dynamic>>(
          url,
          data: {'refresh': refresh},
          options: Options(headers: {'Authorization': null}),
        );
        if (r.statusCode == 200 && r.data is Map) {
          final data = r.data!;
          final map = data['data'] is Map ? (data['data'] as Map) : data;
          final access = map['access']?.toString();
          if (access != null && access.isNotEmpty) {
            await AuthService.setTokens(access: access);
            return access;
          }
        }
      } catch (_) {
        // try next endpoint
      }
    }
    return null;
  }

  static Future<Response<dynamic>> _retryWithNewToken(
    Dio dio,
    RequestOptions o,
    String access,
  ) {
    final headers = Map<String, dynamic>.from(o.headers)
      ..['Authorization'] = 'Bearer $access';

    final opts = Options(
      method: o.method,
      headers: headers,
      responseType: o.responseType,
      contentType: o.contentType,
      followRedirects: o.followRedirects,
      sendTimeout: o.sendTimeout,
      receiveTimeout: o.receiveTimeout,
      validateStatus: o.validateStatus,
    );

    return dio.request<dynamic>(
      o.path,
      data: o.data,
      queryParameters: o.queryParameters,
      options: opts,
      cancelToken: o.cancelToken,
      onSendProgress: o.onSendProgress,
      onReceiveProgress: o.onReceiveProgress,
    );
  }
}
