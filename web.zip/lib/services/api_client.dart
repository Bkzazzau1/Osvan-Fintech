// lib/services/api_client.dart
// Production-minded Dio client for Osvan (Django/DRF + JWT)
// - Env/BACKEND_URL resolution (no trailing slash)
// - Single-flight token refresh (SimpleJWT)
// - X-Skip-Auth to avoid stale Authorization during refresh
// - Uppercase ticker/network for crypto
// - Idempotency-Key header + body on transfer
// - Small retry with backoff on transient 5xx/429
// - LogInterceptor in kDebugMode only
// - Health fallback: /api/v1/health/ -> /api/health/

import 'dart:async';
import 'dart:math';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart' show kDebugMode, debugPrint;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get_storage/get_storage.dart';
import 'package:osvan_app/config/env.dart';

/// ---- Centralized API paths (v1) - keep DRY ----
class ApiPaths {
  // Auth (Django SimpleJWT)
  static const String obtain = '/api/token/'; // ✅ SimpleJWT
  static const String refresh = '/api/token/refresh/'; // ✅ SimpleJWT

  // Health/misc
  static const String healthV1 = '/api/v1/health/';
  static const String healthLegacy = '/api/health/';

  // Wallets
  static const String wallets = '/api/v1/wallets/';
  static const String virtualAccount = '/api/v1/wallets/virtual-account/';
  static const String collectionDetails = '/api/v1/wallets/collection-details/';
  static const String walletCredit = '/api/v1/wallets/credit/';

  // Crypto
  static const String cryptoBalances = '/api/v1/crypto/balances/';
  static const String cryptoAddress = '/api/v1/crypto/address/';
  static const String cryptoTransfer = '/api/v1/transfer/crypto/';
  static const String cryptoTxs = '/api/v1/crypto/transactions/';
  static const String cryptoWalletAddresses =
      '/api/v1/wallets/crypto-addresses/';
}

/// ---- Back-compat aliasing (do not break callers that reference _Api.*) ----
class _Api {
  // Auth
  static const obtain = ApiPaths.obtain;
  static const refresh = ApiPaths.refresh;

  // Wallets
  static const wallets = ApiPaths.wallets;
  static const virtualAccount = ApiPaths.virtualAccount;
  static const collectionDetails = ApiPaths.collectionDetails;
  static const walletCredit = ApiPaths.walletCredit;

  // Crypto
  static const cryptoBalances = ApiPaths.cryptoBalances;
  static const cryptoAddress = ApiPaths.cryptoAddress;
  static const cryptoTransfer = ApiPaths.cryptoTransfer;
  static const cryptoTxs = ApiPaths.cryptoTxs;
  static const cryptoWalletAddresses = ApiPaths.cryptoWalletAddresses;

  // Health/misc
  static const healthV1 = ApiPaths.healthV1;
  static const healthLegacy = ApiPaths.healthLegacy;
}

class _TokenStore {
  final _secure = const FlutterSecureStorage();
  final _box = GetStorage();

  Future<String?> readAccess() async =>
      await _secure.read(key: 'access') ?? _box.read<String>('access');

  Future<String?> readRefresh() async =>
      await _secure.read(key: 'refresh') ?? _box.read<String>('refresh');

  Future<void> writeBoth({required String access, String? refresh}) async {
    try {
      await _secure.write(key: 'access', value: access);
    } catch (_) {}
    await _box.write('access', access);
    if (refresh != null) {
      try {
        await _secure.write(key: 'refresh', value: refresh);
      } catch (_) {}
      await _box.write('refresh', refresh);
    }
  }

  Future<void> clear() async {
    try {
      await _secure.delete(key: 'access');
    } catch (_) {}
    try {
      await _secure.delete(key: 'refresh');
    } catch (_) {}
    await _box.remove('access');
    await _box.remove('refresh');
  }
}

class ApiClient {
  final Dio _dio;
  final _TokenStore _store;

  bool _refreshing = false;
  final List<Completer<void>> _waiters = [];

  ApiClient._(this._dio, this._store);

  static ApiClient? _shared;

  static Future<ApiClient> ensureInitialized() async {
    _shared ??= await ApiClient.create();
    return _shared!;
  }

  static ApiClient get shared =>
      _shared ??
      (throw StateError('ApiClient not initialized. '
          'Call await ApiClient.ensureInitialized() before use.'));

  /// Direct Dio access (handy for advanced cases)
  Dio get raw => _dio;
  Dio get dio => _dio;
  Dio get client => _dio; // legacy alias

  static Future<ApiClient> create() async {
    // Resolve base URL from Env (prod default, overridable via --dart-define)
    final raw = Env.autoBaseUrl;
    final baseUrl = raw.endsWith('/') ? raw.substring(0, raw.length - 1) : raw;

    final dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 20),
      receiveTimeout: const Duration(seconds: 30),
      headers: const {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
      },
    ));

    if (kDebugMode) {
      dio.interceptors.add(LogInterceptor(
        request: true,
        requestBody: true,
        requestHeader: true,
        responseBody: true,
        responseHeader: false,
        error: true,
        logPrint: (obj) => debugPrint(obj.toString()),
      ));
    }

    final store = _TokenStore();
    final client = ApiClient._(dio, store);

    dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final skipAuth = options.headers['X-Skip-Auth']?.toString() == '1';
        if (!skipAuth) {
          final access = await store.readAccess();
          if (access != null && access.isNotEmpty) {
            options.headers['Authorization'] = 'Bearer $access';
          }
        } else {
          options.headers.remove('Authorization');
        }
        handler.next(options);
      },
      onError: (e, handler) async {
        final req = e.requestOptions;
        final alreadyRetried = req.extra['__ret'] == true;
        final isAuthCall = req.path == _Api.refresh || req.path == _Api.obtain;

        if (!isAuthCall && e.response?.statusCode == 401 && !alreadyRetried) {
          final ok = await client._refreshTokens();
          if (ok) {
            final newAccess = await store.readAccess();
            final clone = await dio.fetch(
              req.copyWith(
                headers: {
                  ...req.headers,
                  if (newAccess != null) 'Authorization': 'Bearer $newAccess',
                },
                extra: {...req.extra, '__ret': true},
              ),
            );
            return handler.resolve(clone);
          }
        }
        handler.next(e);
      },
    ));

    return client;
  }

  T _unwrap<T>(dynamic data) {
    if (data is Map) {
      if (data.containsKey('data')) return data['data'] as T;
      if (data.containsKey('results')) return data['results'] as T;
    }
    return data as T;
  }

  Map<String, dynamic> _mapOrEmpty(dynamic data) =>
      (data is Map<String, dynamic>) ? data : <String, dynamic>{};

  Future<bool> _refreshTokens() async {
    if (_refreshing) {
      final waiter = Completer<void>();
      _waiters.add(waiter);
      try {
        await waiter.future;
        return (await _store.readAccess())?.isNotEmpty == true;
      } catch (_) {
        return false;
      }
    }

    _refreshing = true;
    try {
      final refresh = await _store.readRefresh();
      if (refresh == null || refresh.isEmpty) return false;

      try {
        final r = await _dio.post(
          _Api.refresh,
          data: {'refresh': refresh},
          options: Options(
            headers: {'X-Skip-Auth': '1'},
            sendTimeout: const Duration(seconds: 10),
            receiveTimeout: const Duration(seconds: 10),
          ),
        );
        final m = _mapOrEmpty(r.data);
        final access = (m['access'] as String?) ?? '';
        if (access.isNotEmpty) {
          await _store.writeBoth(access: access);
          _flushWaiters();
          return true;
        }
      } catch (_) {}

      _failWaiters();
      await _store.clear();
      return false;
    } finally {
      _refreshing = false;
    }
  }

  void _flushWaiters() {
    for (final w in _waiters) {
      if (!w.isCompleted) w.complete();
    }
    _waiters.clear();
  }

  void _failWaiters() {
    for (final w in _waiters) {
      if (!w.isCompleted) w.completeError(StateError('refresh failed'));
    }
    _waiters.clear();
  }

  // ---------- health ----------
  Future<bool> ping() async {
    // Try v1 first, then legacy path for compatibility
    try {
      final r = await _dio.get(_Api.healthV1,
          options: Options(headers: {'X-Skip-Auth': '1'}));
      return r.statusCode == 200;
    } catch (_) {
      try {
        final r = await _dio.get(_Api.healthLegacy,
            options: Options(headers: {'X-Skip-Auth': '1'}));
        return r.statusCode == 200;
      } catch (_) {
        return false;
      }
    }
  }

  Future<Map<String, dynamic>> whoAmI() async {
    // Lightweight check + echo which path responded
    try {
      final r = await _dio.get(_Api.healthV1,
          options: Options(headers: {'X-Skip-Auth': '1'}));
      return {'ok': r.statusCode == 200, 'path': _Api.healthV1};
    } catch (_) {
      final r = await _dio.get(_Api.healthLegacy,
          options: Options(headers: {'X-Skip-Auth': '1'}));
      return {'ok': r.statusCode == 200, 'path': _Api.healthLegacy};
    }
  }

  // ---------- auth ----------
  /// SimpleJWT login (username/password or email if backend accepts it)
  Future<void> login(
      {required String username, required String password}) async {
    final r = await _dio.post(
      _Api.obtain,
      data: {
        'username': username, // backend may treat this as email
        'password': password,
      },
      options: Options(headers: {'X-Skip-Auth': '1'}),
    );

    final body = _mapOrEmpty(r.data);
    final access = (body['access'] as String?) ?? '';
    final refresh = body['refresh'] as String?;
    if (access.isEmpty) {
      throw DioException(
        requestOptions: r.requestOptions,
        response: r,
        message: 'No access token in response',
        type: DioExceptionType.badResponse,
      );
    }
    await _store.writeBoth(access: access, refresh: refresh);
  }

  Future<void> logout() async {
    await _store.clear();
  }

  // ---------- crypto ----------
  Future<List<dynamic>> listBalances() async {
    final r = await _dio.get(_Api.cryptoBalances);
    return List<dynamic>.from(_unwrap(r.data) as List);
  }

  Future<Map<String, dynamic>> generateAddress({
    required String ticker,
    required String network,
  }) async {
    final r = await _dio.post(_Api.cryptoAddress, data: {
      'ticker': ticker.toUpperCase(),
      'network': network.toUpperCase(),
    });
    return Map<String, dynamic>.from(_unwrap(r.data));
  }

  Future<List<dynamic>> listCryptoReceiveAddresses() async {
    final r = await _dio.get(_Api.cryptoWalletAddresses);
    return List<dynamic>.from(_unwrap(r.data) as List);
  }

  Future<Response<dynamic>> _postWithRetry(
    String path, {
    required Map<String, dynamic> data,
    required Options options,
    int attempts = 3,
    Duration baseDelay = const Duration(milliseconds: 300),
  }) async {
    DioException? last;
    for (var i = 0; i < attempts; i++) {
      try {
        return await _dio.post(path, data: data, options: options);
      } on DioException catch (e) {
        last = e;
        final code = e.response?.statusCode ?? 0;
        final transient = code == 429 || (code >= 500 && code < 600);
        if (!transient || i == attempts - 1) rethrow;
        final jitterMs = Random().nextInt(150);
        final wait =
            baseDelay * pow(2, i).toInt() + Duration(milliseconds: jitterMs);
        await Future.delayed(wait);
      }
    }
    throw last!;
  }

  Future<Map<String, dynamic>> transfer({
    required String ticker,
    required String network,
    required String toAddress,
    required String amount,
    String? idempotencyKey,
  }) async {
    final key = (idempotencyKey != null && idempotencyKey.isNotEmpty)
        ? idempotencyKey
        : DateTime.now().microsecondsSinceEpoch.toString();

    final payload = {
      'ticker': ticker.toUpperCase(),
      'network': network.toUpperCase(),
      'to_address': toAddress,
      'amount': amount,
      'idempotency_key': key, // backend header guard
      'idem': key, // body guard (belt & braces)
    };

    final r = await _postWithRetry(
      _Api.cryptoTransfer,
      data: payload,
      options: Options(headers: {'Idempotency-Key': key}),
    );
    return Map<String, dynamic>.from(_unwrap(r.data));
  }

  Future<List<dynamic>> listTransactions({
    String? ticker,
    String? network,
    String? status,
    String? type,
    int? pageSize,
    int? page,
  }) async {
    final q = <String, dynamic>{
      if (ticker != null) 'ticker': ticker.toUpperCase(),
      if (network != null) 'network': network.toUpperCase(),
      if (status != null) 'status': status,
      if (type != null) 'type': type,
      if (pageSize != null) 'page_size': pageSize,
      if (page != null) 'page': page,
    };
    final r = await _dio.get(_Api.cryptoTxs, queryParameters: q);
    return List<dynamic>.from(_unwrap(r.data) as List);
  }

  // ---------- wallets ----------
  Future<List<dynamic>> listWallets() async {
    final r = await _dio.get(_Api.wallets);
    return List<dynamic>.from(_unwrap(r.data) as List);
  }

  // Quick VA status check (no creation, short timeouts)
  Future<Map<String, dynamic>> getVirtualAccountStatus() async {
    final r = await _dio.get(
      _Api.virtualAccount,
      options: Options(
        sendTimeout: Duration(seconds: 5),
        receiveTimeout: Duration(seconds: 5),
      ),
    );
    return Map<String, dynamic>.from(_unwrap(r.data));
  }

  // Explicit VA creation (user action), longer timeout for provider latency
  Future<Map<String, dynamic>> createVirtualAccount({
    Map<String, dynamic>? data,
  }) async {
    final r = await _dio.post(
      _Api.virtualAccount,
      data: data ?? const <String, dynamic>{},
      options: Options(
        sendTimeout: Duration(seconds: 10),
        receiveTimeout: Duration(seconds: 45),
      ),
    );
    return Map<String, dynamic>.from(_unwrap(r.data));
  }

  // Optional helper: poll until READY (use from controller/UI)
  Future<Map<String, dynamic>?> waitForVAReady({
    Duration pollEvery = const Duration(seconds: 2),
    Duration maxWait = const Duration(seconds: 60),
  }) async {
    final started = DateTime.now();
    Map<String, dynamic> last = {};
    while (DateTime.now().difference(started) < maxWait) {
      last = await getVirtualAccountStatus();
      final status = (last['status'] ?? 'READY').toString().toUpperCase();
      if (status == 'READY') return last;
      if (status == 'FAILED') {
        throw DioException(
          requestOptions: RequestOptions(path: _Api.virtualAccount),
          message:
              last['error']?.toString() ?? 'Virtual account creation failed',
          type: DioExceptionType.badResponse,
        );
      }
      await Future.delayed(pollEvery);
    }
    return null; // UI can show “Still creating… Tap Refresh”
  }

  // --------- Back-compat wrappers (kept to avoid breaking callers) ---------

  /// OLD: getVirtualAccount() → now routes to getVirtualAccountStatus()
  /// Always returns a map with at least {status: ...}
  Future<Map<String, dynamic>> getVirtualAccount() async {
    try {
      final res = await getVirtualAccountStatus();
      return res;
    } on DioException catch (e) {
      if (e.response?.statusCode == 404) {
        return {'status': 'PENDING'};
      }
      rethrow;
    }
  }

  /// OLD: createOrFetchVirtualAccount() → now routes to createVirtualAccount()
  Future<Map<String, dynamic>> createOrFetchVirtualAccount({
    Map<String, dynamic>? data,
  }) async {
    return createVirtualAccount(data: data);
  }

  // Collections (KES/UGX)
  Future<Map<String, dynamic>> getCollectionDetails({
    required String country, // 'KE' or 'UG'
    String? method, // 'momo' or 'bank' if supported
  }) async {
    final q = <String, dynamic>{
      'country': country,
      if (method != null) 'method': method,
    };
    final r = await _dio.get(_Api.collectionDetails, queryParameters: q);
    return Map<String, dynamic>.from(_unwrap(r.data));
  }

  // Optional: credit wallet (for admin tools or test funding)
  Future<Map<String, dynamic>> creditWallet({
    required String currency, // e.g., 'NGN'
    required String amount, // string to avoid float issues
    String? narration,
  }) async {
    final r = await _dio.post(_Api.walletCredit, data: {
      'currency': currency,
      'amount': amount,
      if (narration != null) 'narration': narration,
    });
    return Map<String, dynamic>.from(_unwrap(r.data));
  }
}
