import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../core/colors.dart';

class CloseAccountView extends StatefulWidget {
  const CloseAccountView({super.key});

  @override
  State<CloseAccountView> createState() => _CloseAccountViewState();
}

class _CloseAccountViewState extends State<CloseAccountView> {
  final _formKey = GlobalKey<FormState>();
  final _reasonController = TextEditingController();

  void _submitRequest() {
    if (_formKey.currentState!.validate()) {
      Get.defaultDialog(
        title: "Confirm Closure",
        middleText: "Are you sure you want to close your account?",
        textConfirm: "Yes, Close",
        textCancel: "Cancel",
        confirmTextColor: Colors.white,
        onConfirm: () {
          // TODO: Call backend to submit account closure request
          Get.back(); // Close dialog
          Get.snackbar(
            "Request Sent",
            "Your account closure request has been submitted.",
            backgroundColor: Colors.red,
            colorText: Colors.white,
          );
          Get.offAllNamed("/login"); // Optional: Log out user
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Close Account"),
        backgroundColor: osvanGreen,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                "Please tell us why you're closing your account (optional):",
                style: TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 20),
              TextFormField(
                controller: _reasonController,
                maxLines: 4,
                decoration: const InputDecoration(
                  hintText: "Type your reason here...",
                  border: OutlineInputBorder(),
                ),
              ),
              const Spacer(),
              Center(
                child: ElevatedButton(
                  onPressed: _submitRequest,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 50,
                      vertical: 14,
                    ),
                  ),
                  child: const Text(
                    "Request Account Closure",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
