import 'package:get/get.dart';

import '../models/wallet.dart';
import '../services/wallets_service.dart';

class WalletsController extends GetxController {
  final wallets = <Wallet>[].obs;
  final isLoading = false.obs;
  final error = RxnString();

  /// Auto-load on init; you can remove this and call `load()` from Dashboard if you prefer.
  @override
  void onInit() {
    super.onInit();
    load();
  }

  Future<void> load() async {
    isLoading.value = true;
    error.value = null;
    try {
      final list = await WalletsService.instance.fetchWallets();
      wallets.assignAll(list);
    } catch (e) {
      error.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }

  /// Example helpers (use in UI if needed)
  Wallet? byCode(String code) =>
      wallets.firstWhereOrNull((w) => w.currencyCode == code);

  double sumByCode(String code) => wallets
      .where((w) => w.currencyCode == code)
      .fold<double>(0, (s, w) => s + w.balance);
}
