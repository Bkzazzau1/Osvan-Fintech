// lib/features/wallets/services/wallets_service.dart
import 'package:osvan_app/services/api_client.dart';

import '../models/wallet.dart';

class WalletsService {
  WalletsService(); // unnamed ctor so controllers can do WalletsService()
  WalletsService._();
  static final instance = WalletsService._();

  // Internal helper to ensure ApiClient is ready (safe on hot restart)
  Future<ApiClient> _api() => ApiClient.ensureInitialized();

  // ---------------- Wallets ----------------

  /// Fetch all user wallets (typed to Wallet model)
  Future<List<Wallet>> fetchWallets() async {
    final api = await _api();
    final data = await api.listWallets();
    return data
        .map((e) => Wallet.fromJson(Map<String, dynamic>.from(e)))
        .toList();
  }

  // ---------------- Virtual Account (NGN) ----------------
  // IMPORTANT: We never auto-create a VA here. Controllers call create explicitly.

  /// Get NGN Virtual Account **status/details** (no creation).
  /// Backend should always return a map with at least `{ status: 'PENDING'|'CREATING'|'READY'|'FAILED' }`.
  Future<Map<String, dynamic>> getVirtualAccountStatus() async {
    final api = await _api();
    return await api.getVirtualAccountStatus();
  }

  /// Create NGN Virtual Account explicitly (only when user taps "Get Virtual Account").
  /// Accepts optional KYC payload; returns backend response (often `{status: 'CREATING'}` or READY if fast).
  Future<Map<String, dynamic>> createVirtualAccount(
      {Map<String, dynamic>? kyc}) async {
    final api = await _api();
    return await api.createVirtualAccount(data: kyc);
  }

  /// Poll until VA becomes READY (use in controller after calling createVirtualAccount()).
  /// Returns VA map when READY, `null` if timed out, or throws if status becomes FAILED.
  Future<Map<String, dynamic>?> waitForVAReady({
    Duration pollEvery = const Duration(seconds: 2),
    Duration maxWait = const Duration(seconds: 60),
  }) async {
    final api = await _api();
    return await api.waitForVAReady(pollEvery: pollEvery, maxWait: maxWait);
  }

  // ---------------- Collections (KES/UGX) ----------------

  /// Collections rails (for Kenya/Uganda). Keep UI from calling VA for these countries.
  Future<Map<String, dynamic>> getCollectionDetails({
    required String country, // 'KE' or 'UG'
    String? method, // e.g. 'momo' or 'bank'
  }) async {
    final api = await _api();
    return await api.getCollectionDetails(country: country, method: method);
  }

  // ---------------- Test/Admin Utilities ----------------

  /// Credit a wallet (admin/test). Adjust fields if your backend expects a different payload.
  Future<Map<String, dynamic>> creditWallet({
    required String walletId,
    required String amount,
    String reference = 'test-credit',
    String narration = 'Test credit from app',
  }) async {
    final api = await _api();
    final r = await api.dio.post(
      ApiPaths.walletCredit,
      data: {
        'wallet_id': walletId,
        'amount': amount,
        'reference': reference,
        'narration': narration,
      },
    );
    final data = r.data;
    return Map<String, dynamic>.from(data is Map ? data : {'data': data});
  }
}
