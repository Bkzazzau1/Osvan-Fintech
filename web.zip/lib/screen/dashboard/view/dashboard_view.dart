// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:osvan_app/screen/dashboard/widgets/action_grid.dart';
import 'package:osvan_app/screen/dashboard/widgets/services_and_activity.dart';
import 'package:osvan_app/screen/dashboard/widgets/wallet_balance_section.dart';
// ✅ make sure this path matches where you created the controller:
import 'package:osvan_app/screen/wallet/controllers/wallets_controller.dart';
import 'package:osvan_app/screen/wallet/services/config_service.dart';
// ✅ Control API config (flags/defaults/rates)


class DashboardView extends StatefulWidget {
  const DashboardView({super.key});

  @override
  State<DashboardView> createState() => _DashboardViewState();
}

class _DashboardViewState extends State<DashboardView> {
  @override
  void initState() {
    super.initState();
    final wc = Get.put(WalletsController(), permanent: true);
    wc.load(); // safe even if onInit already loads
  }

  @override
  Widget build(BuildContext context) {
    final cfg = Get.find<ConfigService>(); // registered in main()

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Obx(() {
        final usdOnly = cfg.usdCardOnly;
        final canFund = cfg.cardsFundEnabled;
        final canWithdraw = cfg.cardsWithdrawEnabled;

        final List<Widget> notices = [];
        if (usdOnly) {
          notices.add(_NoticeChip(
            text: 'Cards are USD-only for now.',
            icon: Icons.info_outline,
          ));
        }
        if (!canFund || !canWithdraw) {
          final parts = [
            if (!canFund) 'funding',
            if (!canWithdraw) 'withdrawal',
          ].join(' & ');
          notices.add(_NoticeChip(
            text: 'Card $parts temporarily disabled.',
            icon: Icons.warning_amber_outlined,
          ));
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const WalletBalanceSection(),
              if (notices.isNotEmpty) const SizedBox(height: 12),
              if (notices.isNotEmpty)
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: notices,
                ),
              const SizedBox(height: 24),
              const ActionGrid(),
              const SizedBox(height: 24),
              const ServicesAndActivity(),
            ],
          ),
        );
      }),
    );
  }
}

class _NoticeChip extends StatelessWidget {
  final String text;
  final IconData icon;
  const _NoticeChip({required this.text, required this.icon});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bg = isDark ? Colors.white10 : Colors.black.withOpacity(0.05);
    final fg = isDark ? Colors.white : Colors.black87;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: fg.withOpacity(0.08)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 18, color: fg.withOpacity(0.8)),
          const SizedBox(width: 8),
          Text(
            text,
            style:
                TextStyle(color: fg, fontSize: 13, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}
