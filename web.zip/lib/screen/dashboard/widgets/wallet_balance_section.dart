import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:osvan_app/core/colors.dart';
import 'package:osvan_app/screen/wallet/controllers/wallets_controller.dart';
import 'package:osvan_app/screen/wallet/models/wallet.dart';

class WalletBalanceSection extends StatefulWidget {
  const WalletBalanceSection({super.key});

  @override
  State<WalletBalanceSection> createState() => _WalletBalanceSectionState();
}

class _WalletBalanceSectionState extends State<WalletBalanceSection> {
  String? _selectedCode; // currency_code like "NGN", "USD"

  @override
  Widget build(BuildContext context) {
    final wc = Get.find<WalletsController>();

    return Obx(() {
      if (wc.isLoading.value) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
              color: osvanGreen, borderRadius: BorderRadius.circular(12)),
          child: const Center(
              child: CircularProgressIndicator(color: Colors.white)),
        );
      }

      if (wc.error.value != null) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
              color: osvanGreen, borderRadius: BorderRadius.circular(12)),
          child: Text(
            'Failed to load wallets: ${wc.error.value}',
            style: const TextStyle(color: Colors.white),
          ),
        );
      }

      final List<Wallet> wallets = wc.wallets;
      if (wallets.isEmpty) {
        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
              color: osvanGreen, borderRadius: BorderRadius.circular(12)),
          child: const Text('No wallets yet',
              style: TextStyle(color: Colors.white)),
        );
      }

      // Selected currency_code fallback to the first wallet if null/invalid
      final codes = wallets.map((w) => w.currencyCode).toList();
      _selectedCode = _selectedCode != null && codes.contains(_selectedCode)
          ? _selectedCode
          : wallets.first.currencyCode;

      final selected =
          wallets.firstWhere((w) => w.currencyCode == _selectedCode);

      return Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: osvanGreen,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _SemiBold(
                text: 'Wallet Balance', color: Colors.white, size: 16),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _Bold(
                  text:
                      '${_symbolFor(selected.currencyCode)}${selected.balance.toStringAsFixed(2)}',
                  color: Colors.white,
                  size: 28,
                ),
                Flexible(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    dropdownColor: osvanGreen,
                    value: _selectedCode,
                    icon:
                        const Icon(Icons.arrow_drop_down, color: Colors.white),
                    underline: const SizedBox(),
                    onChanged: (value) => setState(() => _selectedCode = value),
                    items: wallets.map((w) {
                      final code = w.currencyCode;
                      final symbol = _symbolFor(code);
                      return DropdownMenuItem(
                        value: code,
                        child: Text(
                          '$symbol ($code)',
                          style: const TextStyle(
                              color: Colors.white, fontSize: 13),
                          overflow: TextOverflow.ellipsis,
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    });
  }

  // quick symbol map; extend as needed
  String _symbolFor(String code) {
    const map = {
      'NGN': '₦',
      'USD': '\$',
      'GBP': '£',
      'EUR': '€',
      'XOF': 'CFA',
      'AED': 'د.إ',
      'KES': 'KSh',
      'GHS': '₵',
      'UGX': 'USh',
      'ZMW': 'ZK',
      'MWK': 'MK',
      'GNF': 'FG',
      'CNY': '¥',
      'CDF': 'FC',
      'SGD': 'S\$',
      'AUD': 'A\$',
      // add more as needed
    };
    return map[code] ?? '';
  }
}

class _Bold extends StatelessWidget {
  final String text;
  final Color color;
  final double size;
  const _Bold({required this.text, required this.color, required this.size});

  @override
  Widget build(BuildContext context) => Text(text,
      style:
          TextStyle(color: color, fontSize: size, fontWeight: FontWeight.bold));
}

class _SemiBold extends StatelessWidget {
  final String text;
  final Color color;
  final double size;
  const _SemiBold(
      {required this.text, required this.color, required this.size});

  @override
  Widget build(BuildContext context) => Text(text,
      style:
          TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w600));
}
