// lib/screen/transaction/services/transactions_service.dart
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:osvan_app/services/api_client.dart';

import '../models/transaction.dart';

class TransactionsService {
  TransactionsService._();
  static final TransactionsService instance = TransactionsService._();

  static const String _basePath = '/api/v1/transactions/';

  Future<List<Txn>> fetchPage({
    required int page,
    required int pageSize,
    String? walletId,
    String include = 'all', // 'all' | 'fiat' | 'crypto'
    String order = 'desc', // 'asc' | 'desc'
  }) async {
    // ✅ Use the shared singleton — no default constructor.
    final Dio dio = ApiClient.shared.dio;

    // Send both styles so backend can accept either branch.
    final qp = <String, dynamic>{
      // DRF-like pagination (preferred by our patched backend)
      'page': page,
      'page_size': pageSize,

      // Fallback (harmless for servers that ignore it)
      'offset': (page - 1) * pageSize,
      'limit': pageSize,

      // Merged feed controls
      'include': include,
      'order': order,

      if (walletId != null && walletId.isNotEmpty) 'wallet': walletId,
    };

    try {
      final res = await dio.get(_basePath, queryParameters: qp);

      // Handle either a raw list or a paginated map with `results`
      if (res.data is List) {
        return (res.data as List)
            .map((e) => Txn.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      if (res.data is Map) {
        final map = res.data as Map<String, dynamic>;
        final results = (map['results'] as List<dynamic>? ?? []);
        return results
            .map((e) => Txn.fromJson(e as Map<String, dynamic>))
            .toList();
      }

      throw StateError(
        'Unexpected transactions response shape: ${res.data.runtimeType}',
      );
    } on DioException catch (e) {
      final msg = e.response?.data is Map
          ? (e.response!.data['detail']?.toString() ??
              e.response!.data['message']?.toString() ??
              e.message)
          : e.message;
      if (kDebugMode) {
        // ignore: avoid_print
        print('TransactionsService.fetchPage error: $msg');
      }
      throw Exception(msg ?? 'Failed to load transactions');
    } catch (e) {
      if (kDebugMode) {
        // ignore: avoid_print
        print('TransactionsService.fetchPage error: $e');
      }
      throw Exception('Failed to load transactions');
    }
  }
}
