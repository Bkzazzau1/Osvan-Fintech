// lib/main.dart
// ignore_for_file: deprecated_member_use, duplicate_ignore

import 'dart:async' show unawaited;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart'; // ✅ added
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:osvan_app/config/env.dart'; // ✅ backend URL source
import 'package:osvan_app/controller/theme_controller.dart';
import 'package:osvan_app/core/colors.dart';
import 'package:osvan_app/routes/app_routes.dart';
import 'package:osvan_app/screen/wallet/services/config_service.dart';
import 'package:osvan_app/services/api_client.dart'; // ✅ init API client

// 🔹 Debug-only login probe to verify Django /api/token/ works end-to-end.
//    This does NOT block app startup and runs only in debug builds.
import 'auth_test.dart' show testEmailLogin;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ✅ Load .env.production first (non-fatal if missing)
  try {
    await dotenv.load(fileName: '.env.production');
  } catch (_) {
    // no-op; fall back to constants/providers
  }

  // ✅ Local storage (used by token store & config cache)
  await GetStorage.init();

  // ✅ Load Control API config (flags/defaults/rates) before UI mounts
  await ConfigService.init();

  // ✅ Initialize API client BEFORE controllers or UI
  await ApiClient.ensureInitialized();

  // ✅ Register controllers
  Get.put(ThemeController());

  // ✅ Optional debug diagnostics (safe to remove later)
  if (kDebugMode) {
    final box = GetStorage();
    final cfg = Get.find<ConfigService>();
    // ignore: avoid_print
    print('Backend URL: ${Env.apiBaseUrl}');
    // ignore: avoid_print
    print('Access token (stored): ${box.read('access')}');
    // ignore: avoid_print
    print('Refresh token (stored): ${box.read('refresh')}');

    // Control API snapshot
    // ignore: avoid_print
    print(
        'Config: fund=${cfg.cardsFundEnabled}, withdraw=${cfg.cardsWithdrawEnabled}, usdOnly=${cfg.usdCardOnly}, fee=${cfg.conversionFeePct}');
    // ignore: avoid_print
    print('FX USD->NGN: ${cfg.rateFor('NGN')}');

    // Non-blocking health ping
    unawaited(_debugPing());

    // Non-blocking token smoke test against /api/token/
    // Uses Email+Password per the Django change we deployed.
    unawaited(testEmailLogin());
  }

  // ✅ System UI (status/navigation bar colors)
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: osvanGreen,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarColor: osvanGreen,
      systemNavigationBarIconBrightness: Brightness.light,
    ),
  );

  runApp(const MyApp());
}

Future<void> _debugPing() async {
  try {
    final ok = await ApiClient.shared.ping();
    // ignore: avoid_print
    print('API health ping ok? $ok');
  } catch (e) {
    // ignore: avoid_print
    print('API health ping failed: $e');
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ThemeController>(
      builder: (themeController) {
        return GetMaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Osvan',
          themeMode: themeController.themeMode,

          // ✅ Light Theme
          theme: ThemeData(
            brightness: Brightness.light,
            scaffoldBackgroundColor: osvanWhite,
            primaryColor: osvanGreen,
            fontFamily: 'Poppins',
            cardColor: osvanWhite,
            inputDecorationTheme: InputDecorationTheme(
              labelStyle: const TextStyle(color: osvanBlack),
              filled: true,
              fillColor: osvanGrey.withOpacity(0.2),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
            textTheme: const TextTheme(
              bodyLarge: TextStyle(color: osvanBlack, fontSize: 16),
              bodyMedium: TextStyle(color: osvanBlack, fontSize: 14),
              titleLarge: TextStyle(
                fontWeight: FontWeight.bold,
                color: osvanBlack,
              ),
            ),
            appBarTheme: const AppBarTheme(
              backgroundColor: osvanWhite,
              elevation: 0,
              iconTheme: IconThemeData(color: osvanBlack),
              titleTextStyle: TextStyle(
                color: osvanBlack,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
              ),
            ),
          ),

          // ✅ Dark Theme
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            scaffoldBackgroundColor: osvanDarkBackground,
            primaryColor: osvanDarkAccent,
            fontFamily: 'Poppins',
            cardColor: osvanDarkCard,
            inputDecorationTheme: InputDecorationTheme(
              labelStyle: const TextStyle(color: osvanWhite),
              filled: true,
              fillColor: osvanBlack.withOpacity(0.2),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
            textTheme: const TextTheme(
              bodyLarge: TextStyle(color: osvanWhite, fontSize: 16),
              bodyMedium: TextStyle(color: osvanWhite, fontSize: 14),
              titleLarge: TextStyle(
                fontWeight: FontWeight.bold,
                color: osvanWhite,
              ),
            ),
            appBarTheme: const AppBarTheme(
              backgroundColor: osvanDarkCard,
              elevation: 0,
              iconTheme: IconThemeData(color: osvanWhite),
              titleTextStyle: TextStyle(
                color: osvanWhite,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Poppins',
              ),
            ),
          ),

          // ✅ Navigation routes
          initialRoute: AppRoutes.welcome,
          getPages: AppRoutes.pages,
        );
      },
    );
  }
}
